#include <iostream>
#include "list.h"
#include "TreapNode.h"
using namespace std;

int main() {
	list l;
	l.file();
	l.display();
	cout << "\n";
    BST b;
	b.files();
}